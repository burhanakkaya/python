# coding=utf-8

"""
    Dizi içinde 0,1 veya 1 den fazla eleman bulunduran kümelerdir
"""

dizi_1 = [45, 13, 32, "özcan", "abc"]

for i in dizi_1:
    print(i)

"""
Output:

45
13
32
özcan
abc

Process finished with exit code 0
"""

# ---------------------------------------------------- #

print(dizi_1[0])  # 45)

print(dizi_1[2])  # 32)
