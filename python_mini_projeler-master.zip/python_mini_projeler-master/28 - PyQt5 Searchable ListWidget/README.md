# Searchable ListWidget

A list widget with searching/filtering implemented

|Initial|Searched|
|-------|--------|
|![initial](../assets/28/1.png)|![initial](../assets/28/2.png)|
