# Python Mini Projeler

> Dokumantasyon linki: [https://ozcanyarimdunya.github.io/python_mini_projeler](https://ozcanyarimdunya.github.io/python_mini_projeler)
> 
> Dokumantasyon gelistirme asamasindadir, her turlu yardimlariniz kabul edilir 😊😁❤️

Boş zamanlarımda hobi olarak eğitim serisi tarzında python da yazdığım mini mini projeler bunlar :)

Bütün proje dosyalarına gerekli açıklamaları elimden geldigince yazdım.

Çok az programlama bilgisi olan biri için başlangıç/orta/ileri seviyelerde yararlı olabileceğini düşündüğüm uygulamaları yazdım.

**NOT** 
> Sisteminizde Python3 kurulu olmasi lazim
> 
> Kodları PyCharm Editorünü kullanarak yazdım. 
> 
> Kodları Windowsta hiç denemedim ne sonuçlar vereceğini bilmiyorum, bi hata varsa pull request acin
----

### Kurulum

Oncelikle bir terminal acip repoyu indirin

```bash
git clone https://github.com/ozcanyarimdunya/python_mini_projeler.git python3_projeler
cd python3_projeler/
```

Pesinden isterleri kurunuz

```bash
pip install --user poetry
poetry install
```
