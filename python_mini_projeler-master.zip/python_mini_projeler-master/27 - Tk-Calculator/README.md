## Calculator with Tkinter 

```
python3 calculator.py
```





![calculator.png](../assets/27/calc.png)
