Veri varken    |   Veri yokken
-----| -----
![](../assets/24/1.png) | ![](../assets/24/2.png)
